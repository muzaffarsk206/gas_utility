# online gas booking system using django
 the system will help the customers by providing a simple user interactive interface for booking gas online
 
 **************************************************************************************************************************
 i have already created a virtual environment in the name of baba

 step by step procedure to run the online gas booking system after downloading or cloning the respiratory

 first and foremost thing, check whether python path is assigned to system variable(environmen variable) or not?

 second step is to activate virtual env(baba) or create your own virtual env for efficient deployment process
 
 process for activating the virtual env(baba) is
 -----------------------------------------------cd baba
 -----------------------------------------------cd scripts
 -----------------------------------------------./activate,activate
 -----------------------------------------------cd..
 -----------------------------------------------cd..
 
 after activating the virtual environment then download the requirements like django.
 pip install django
 
next run the script file
python manage.py runserver

for admin username and password is admin
